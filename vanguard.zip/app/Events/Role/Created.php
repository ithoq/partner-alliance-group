<?php

namespace Vanguard\Events\Role;

class Created extends RoleEvent {}